USE [AdventureWorksDW2016]
GO


CREATE TABLE [dbo].[DimProduct_Match](
	[ProductKey] [int] NULL,
	[EnglishProductName] [nvarchar](100) NULL,
	[ProductAlternateKey] [nvarchar](100) NULL,
	[ProductSubcategoryKey] [int] NULL,
	[Match_] bit  NULL
) ON [PRIMARY]
GO
CREATE TABLE [dbo].[DimProduct_NoMatch](
	[ProductKey] [int] NULL,
	[EnglishProductName] [nvarchar](100) NULL,
	[ProductAlternateKey] [nvarchar](100) NULL,
	[ProductSubcategoryKey] [int] NULL,
	[NoMatch] bit NULL
) ON [PRIMARY]