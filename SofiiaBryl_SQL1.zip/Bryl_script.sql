CREATE DATABASE HW2
GO
USE HW2
GO

CREATE TABLE Employees (
    EmployeeID INT IDENTITY(1,1) PRIMARY KEY,
    FirstName VARCHAR(100) NOT NULL,
    LastName VARCHAR(100) NOT NULL,
    Email VARCHAR(255) UNIQUE NOT NULL,
    HireDate DATE NOT NULL
);

CREATE TABLE Projects (
    ProjectID INT IDENTITY(1,1) PRIMARY KEY,
    ProjectName VARCHAR(255) NOT NULL,
    CreationDate DATE NOT NULL,
    State_ VARCHAR(10) CHECK (State_ IN ('Open', 'Closed')) NOT NULL,
    CloseDate DATE NULL
);

CREATE TABLE EmployeeProjectRoles (
    EmployeeID INT,
    ProjectID INT,
    Role_ NVARCHAR(100) NOT NULL,
    PRIMARY KEY (EmployeeID, ProjectID),
    FOREIGN KEY (EmployeeID) REFERENCES Employees(EmployeeID),
    FOREIGN KEY (ProjectID) REFERENCES Projects(ProjectID)
);

CREATE TABLE Tasks (
    TaskID INT IDENTITY(1,1) PRIMARY KEY,
    ProjectID INT NOT NULL,
    AssignedEmployeeID INT NOT NULL,
    Description_ NVARCHAR(500) NOT NULL,
    FOREIGN KEY (ProjectID) REFERENCES Projects(ProjectID),
    FOREIGN KEY (AssignedEmployeeID) REFERENCES Employees(EmployeeID)
);

CREATE TABLE TaskStatuses (
    StatusID INT IDENTITY(1,1) PRIMARY KEY,
    TaskID INT NOT NULL,
    Status_ VARCHAR(20) CHECK (Status_ IN ('Open', 'Done', 'Need Work', 'Accepted')) NOT NULL,
    ChangeDate DATETIME NOT NULL DEFAULT GETDATE(),
    ChangedByEmployeeID INT NOT NULL,
    FOREIGN KEY (TaskID) REFERENCES Tasks(TaskID),
    FOREIGN KEY (ChangedByEmployeeID) REFERENCES Employees(EmployeeID)
);

INSERT INTO Employees (FirstName, LastName, Email, HireDate) VALUES
('John', 'Doe', 'john.doe@example.com', '2020-01-15'),
('Jane', 'Smith', 'jane.smith@example.com', '2019-06-23'),
('Alice', 'Johnson', 'alice.johnson@example.com', '2021-03-10');

INSERT INTO Projects (ProjectName, CreationDate, State_, CloseDate) VALUES
('Project Alpha', '2023-01-10', 'Open', NULL),
('Project Beta', '2022-06-15', 'Closed', '2023-01-01');

INSERT INTO EmployeeProjectRoles (EmployeeID, ProjectID, Role_) VALUES
(1, 1, 'Developer'),
(2, 1, 'Project Manager'),
(3, 2, 'Tester');

INSERT INTO Tasks (ProjectID, AssignedEmployeeID, Description_) VALUES
(1, 1, 'Develop login module'),
(1, 2, 'Create project plan'),
(2, 3, 'Test payment gateway');

INSERT INTO TaskStatuses (TaskID, Status_, ChangeDate, ChangedByEmployeeID) VALUES
(1, 'Open', '2024-01-10 10:00:00', 1),
(2, 'Done', '2024-01-12 14:30:00', 2),
(3, 'Need Work', '2024-01-15 09:45:00', 3);