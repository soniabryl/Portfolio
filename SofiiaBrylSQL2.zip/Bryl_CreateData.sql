USE CompanyProjectsDB;
GO

-- Insert Roles
INSERT INTO Role (RoleName) VALUES 
(N'Developer'), 
(N'Project Manager'), 
(N'QA Engineer');
GO

-- Insert Employees
INSERT INTO Employee (FirstName, LastName, RoleID) VALUES 
(N'John', N'Doe', 1),
(N'Jane', N'Smith', 2),
(N'Emily', N'Davis', 3);
GO

-- Insert Projects
INSERT INTO Project (ProjectName, CreationDate, Status) VALUES 
(N'Project A', '2023-01-01', 'Open'),
(N'Project B', '2023-02-01', 'Open');
GO

-- Assign Employees to Projects
INSERT INTO ProjectEmployee (ProjectID, EmployeeID, RoleID) VALUES 
(1, 1, 1),
(1, 2, 2),
(2, 3, 3);
GO

-- Insert Tasks
INSERT INTO Task (ProjectID, AssignedEmployeeID, TaskName, Deadline, Status) VALUES 
(1, 1, N'Develop Feature X', '2023-06-01', 'Open'),
(1, 2, N'Manage Documentation', '2023-06-05', 'Done'),
(2, 3, N'Test the API', '2023-06-10', 'Need Work');
GO

-- Insert Task Status History
INSERT INTO TaskStatusHistory (TaskID, Status, ChangeDate, ChangedByEmployeeID) VALUES 
(1, 'Open', '2023-05-01', 1),
(2, 'Done', '2023-05-02', 2),
(3, 'Need Work', '2023-05-03', 3);
GO
