-- Create Database
CREATE DATABASE CompanyProjectsDB;
GO
USE CompanyProjectsDB;
GO

CREATE TABLE Role (
    RoleID INT IDENTITY(1,1) PRIMARY KEY,
    RoleName NVARCHAR(255) UNIQUE NOT NULL
);
GO

CREATE TABLE Employee (
    EmployeeID INT IDENTITY(1,1) PRIMARY KEY,
    FirstName NVARCHAR(255) NOT NULL,
    LastName NVARCHAR(255) NOT NULL,
    RoleID INT NULL,
    FOREIGN KEY (RoleID) REFERENCES Role(RoleID)
);
GO

CREATE TABLE Project (
    ProjectID INT IDENTITY(1,1) PRIMARY KEY,
    ProjectName NVARCHAR(255) NOT NULL,
    CreationDate DATE NOT NULL,
    Status NVARCHAR(10) CHECK (Status IN ('Open', 'Closed')) NOT NULL,
    CloseDate DATE NULL
);
GO


CREATE TABLE ProjectEmployee (
    ProjectID INT NOT NULL,
    EmployeeID INT NOT NULL,
    RoleID INT NOT NULL,
    PRIMARY KEY (ProjectID, EmployeeID),
    FOREIGN KEY (ProjectID) REFERENCES Project(ProjectID),
    FOREIGN KEY (EmployeeID) REFERENCES Employee(EmployeeID),
    FOREIGN KEY (RoleID) REFERENCES Role(RoleID)
);
GO


CREATE TABLE Task (
    TaskID INT IDENTITY(1,1) PRIMARY KEY,
    ProjectID INT NOT NULL,
    AssignedEmployeeID INT NOT NULL,
    TaskName NVARCHAR(255) NOT NULL,
    Deadline DATE NOT NULL,
    Status NVARCHAR(15) CHECK (Status IN ('Open', 'Done', 'Need Work', 'Accepted')) NOT NULL,
    FOREIGN KEY (ProjectID) REFERENCES Project(ProjectID),
    FOREIGN KEY (AssignedEmployeeID) REFERENCES Employee(EmployeeID)
);
GO

CREATE TABLE TaskStatusHistory (
    TaskStatusID INT IDENTITY(1,1) PRIMARY KEY,
    TaskID INT NOT NULL,
    Status NVARCHAR(15) CHECK (Status IN ('Open', 'Done', 'Need Work', 'Accepted')) NOT NULL,
    ChangeDate DATE NOT NULL,
    ChangedByEmployeeID INT NOT NULL,
    FOREIGN KEY (TaskID) REFERENCES Task(TaskID),
    FOREIGN KEY (ChangedByEmployeeID) REFERENCES Employee(EmployeeID)
);
GO
